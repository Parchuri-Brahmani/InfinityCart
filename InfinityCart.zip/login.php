<?php
include("php/db.php");
session_start();

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn,$query);

    if(mysqli_num_rows($result)>0){
        $_SESSION['user']=$email;
        header("Location: index.php");
    }else{
        $error = "Invalid Email or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Infinity Cart</title>
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
    <style>
        body {
            background: #f7f7f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .login-container h2 {
            margin-bottom: 25px;
            font-weight: 700;
            color: #222;
        }
        .login-container input {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #eee;
            border-radius: 5px;
            outline: none;
        }
        .login-container button {
            width: 100%;
            background: #1ab394;
            color: white;
            border: none;
            padding: 12px;
            font-weight: 600;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        .login-container button:hover {
            background: #148e75;
        }
        .error-msg {
            color: #e74c3c;
            margin-bottom: 15px;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Login to Infinity Cart</h2>
    
    <?php if(isset($error)) echo "<p class='error-msg'>$error</p>"; ?>

    <form method="POST">
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Login Now</button>
    </form>
    
    <p style="margin-top:20px; font-size:14px; color:#666;">
        Don't have an account? <a href="register.php" style="color:#1ab394; text-decoration:none;">Register here</a>
    </p>
</div>

</body>
</html>