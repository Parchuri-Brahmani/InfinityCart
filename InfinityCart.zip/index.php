<?php
session_start();
include("php/db.php");

// 1. Dynamic Counts Fetching Logic
$cart_count = 0;
$wish_count = 0;

if(isset($_SESSION['user'])){
    $user_email = $_SESSION['user'];
    
    // Cart Count
    $cart_q = "SELECT SUM(quantity) as total FROM cart WHERE user_email = '$user_email'";
    $cart_res = mysqli_query($conn, $cart_q);
    $cart_data = mysqli_fetch_assoc($cart_res);
    $cart_count = ($cart_data && $cart_data['total']) ? $cart_data['total'] : 0;

    // Wishlist Count
    $wish_q = "SELECT COUNT(*) as total FROM wishlist WHERE user_email = '$user_email'";
    $wish_res = mysqli_query($conn, $wish_q);
    $wish_data = mysqli_fetch_assoc($wish_res);
    $wish_count = ($wish_data && $wish_data['total']) ? $wish_data['total'] : 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Infinity Cart</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <style>
        /* Search Bar & Product Card Layout Fixes */
        .search-bar form { display: flex; width: 100%; border: 2px solid #1ab394; border-radius: 50px; overflow: hidden; background: #fff; }
        .search-bar input { flex: 1; border: none; padding: 12px 20px; outline: none; }
        .search-bar select { border: none; border-left: 1px solid #eee; padding: 0 15px; outline: none; background: #f9f9f9; cursor: pointer; }
        .search-bar button { background: #1ab394; color: white; border: none; padding: 0 25px; cursor: pointer; }

        .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 25px; margin-top: 30px; }
        .p-card { background: #fff; border: 1px solid #f0f0f0; border-radius: 10px; overflow: hidden; transition: 0.3s; display: flex; flex-direction: column; height: 100%; position: relative; }
        .p-card:hover { transform: translateY(-8px); box-shadow: 0 10px 20px rgba(0,0,0,0.08); }
        .p-img { width: 100%; height: 220px; display: flex; align-items: center; justify-content: center; background: #fdfdfd; padding: 15px; }
        .p-img img { max-width: 100%; max-height: 100%; object-fit: contain; }
        .p-info { padding: 15px; text-align: center; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; }
        .p-info h4 { font-size: 15px; margin: 10px 0; height: 40px; overflow: hidden; }
        .price { font-size: 18px; font-weight: 700; color: #1ab394; margin-bottom: 15px; }
        .tag-sale { position: absolute; top: 10px; left: 10px; background: #e74c3c; color: white; padding: 2px 8px; font-size: 10px; font-weight: bold; border-radius: 3px; z-index: 1; }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
</head>
<body>

<div class="top-bar">
    <div class="container flex-between">
        <div class="contact">
            <span><i class="fa fa-envelope"></i> support@infinitycart.com</span> | 
            <span><i class="fa fa-phone"></i> +91 9876543210</span>
        </div>
        <div class="top-links">
            <?php if(isset($_SESSION['user'])): ?>
                Welcome, <strong><?php echo $_SESSION['user']; ?></strong> | 
                <a href="account.php">My Account</a>
            <?php else: ?>
                Welcome to Our Store! | <a href="login.php">Login / Register</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<header class="header-main">
    <div class="container flex-between">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color:inherit;">Infinity<span>Cart.</span></a>
        </div>
        
        <div class="search-bar">
            <form action="shop.php" method="GET">
                <input type="text" name="search" placeholder="Search for products, categories, sku..." 
                       value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
                <select name="category_search">
                    <option value="">All Categories</option>
                    <option value="Men">Men</option>
                    <option value="Women">Women</option>
                    <option value="Electronics">Electronics</option>
                </select>
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>

        <div class="header-icons">
            <a href="<?php echo isset($_SESSION['user']) ? 'account.php' : 'login.php'; ?>" style="text-decoration:none; color:inherit;">
                <div class="h-icon">
                    <i class="fa-regular fa-user"></i>
                    <span>Account</span>
                </div>
            </a>
            
            <a href="wishlist.php" style="text-decoration:none; color:inherit;">
                <div class="h-icon">
                    <i class="fa-regular fa-heart"></i>
                    <span class="count"><?php echo $wish_count; ?></span>
                    <span>Wishlist</span>
                </div>
            </a>
            
            <a href="cart.php" style="text-decoration:none; color:inherit;">
                <div class="h-icon">
                    <i class="fa fa-bag-shopping"></i>
                    <span class="count"><?php echo $cart_count; ?></span>
                    <span>Cart</span>
                </div>
            </a>
        </div>
    </div>
</header>

<nav class="nav-green">
    <div class="container flex-between" style="justify-content: flex-start; display: flex; align-items: center;">
        <div class="cat-dropdown" style="white-space: nowrap; position: relative;">
            <i class="fa fa-bars"></i> SHOPPING BY CATEGORIES
            <div class="dropdown-content">
                <a href="shop.php?category=Men">Men's Fashion</a>
                <a href="shop.php?category=Women">Women's Fashion</a>
                <a href="shop.php?category=Electronics">Electronics</a>
                <a href="shop.php?category=Watches">Watches</a>
            </div>
        </div>

        <ul class="main-nav" style="display: flex; list-style: none; margin: 0; padding: 0;">
            <li><a href="index.php" class="active">Home</a></li>
            <li><a href="shop.php">Shop</a></li>
            <li class="has-children">
                <a href="#">Pages <i class="fa fa-chevron-down" style="font-size: 10px;"></i></a>
                <ul class="sub-menu">
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="faq.php">FAQ</a></li>
                    <li><a href="terms.php">Terms & Conditions</a></li>
                </ul>
            </li>
            <li><a href="blog.php">Blog</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </div>
</nav>

<div class="container" style="margin-top: 20px;">
    <section class="hero-slider swiper">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
    <div class="hero-inner" style="background: linear-gradient(to right, rgba(255,255,255,0.6), transparent);">
        <div class="hero-text" style="left: 8%; right: auto; text-align: left;">
            <h4 style="color: #1ab394; font-weight: 700; text-transform: uppercase; letter-spacing: 2px;">Summer Sale</h4>
            <h1 style="color: #222; font-size: 65px; font-weight: 800; line-height: 1.1;">NEW <br>COLLECTIONS</h1>
            <h3 style="color: #555; font-size: 24px; margin-bottom: 25px;">UPTO 65% OFF</h3>
            <a href="shop.php" class="btn-dark" style="text-decoration:none; background: #1ab394; padding: 15px 40px; border-radius: 4px; font-weight: 700;">Shop Now</a>
        </div>
        <div class="hero-img">
            <img src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800" alt="Fashion Sale">
        </div>
    </div>
</div>
            
            <div class="swiper-slide">
                <div class="hero-inner" style="background: #f0f4f7;">
                    <div class="hero-text">
                        <h4>Gadget Fest</h4>
                        <h1>TECH GEAR</h1>
                        <h3>LATEST GADGETS</h3>
                        <a href="shop.php?category=Electronics" class="btn-dark" style="text-decoration:none;">Explore Tech</a>
                    </div>
                    <div class="hero-img">
                        <img src="images/slidertechimage.jpg" alt="Electronics">
                    </div>
                </div>
            </div>
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination"></div>
    </section>
</div>



<section class="trust-badges container" style="display: flex; justify-content: space-around; padding: 40px 0; border-top: 1px solid #eee;">
    <div class="badge-item" style="text-align: center;">
        <i class="fa fa-truck" style="font-size: 30px; color: #1ab394;"></i>
        <h4 style="margin-top: 10px;">Free Shipping</h4>
        <p style="font-size: 12px; color: #888;">On orders above ₹999</p>
    </div>
    <div class="badge-item" style="text-align: center;">
        <i class="fa fa-rotate-left" style="font-size: 30px; color: #1ab394;"></i>
        <h4 style="margin-top: 10px;">Easy Returns</h4>
        <p style="font-size: 12px; color: #888;">7-day return policy</p>
    </div>
    <div class="badge-item" style="text-align: center;">
        <i class="fa fa-lock" style="font-size: 30px; color: #1ab394;"></i>
        <h4 style="margin-top: 10px;">Secure Payment</h4>
        <p style="font-size: 12px; color: #888;">100% safe transactions</p>
    </div>
</section>

<section class="container deals-section" style="margin-top: 50px;">
    <div class="section-title">
        <h2 style="font-weight: 600;">Deals Of The Day</h2>
    </div>
    <div class="product-grid">
        <?php
        $product_query = "SELECT * FROM products LIMIT 10"; 
        $product_result = mysqli_query($conn, $product_query);
        while($row = mysqli_fetch_assoc($product_result)):
            // Image handling update
            $image_src = $row['image'];
            if (!filter_var($image_src, FILTER_VALIDATE_URL)) {
                $image_src = "images/" . $image_src;
            }
        ?>
            <div class="p-card">
                <div class="tag-sale">SALE</div>
                <div class="p-img">
                    <img src="<?php echo $image_src; ?>" 
                         onerror="this.src='https://via.placeholder.com/220x220?text=No+Image'"
                         alt="<?php echo htmlspecialchars($row['name']); ?>">
                </div>
                <div class="p-info">
                    <div>
                        <span class="p-cat"><?php echo $row['category']; ?></span>
                        <h4><?php echo $row['name']; ?></h4>
                        <div class="price">₹<?php echo number_format($row['price'], 2); ?></div>
                    </div>
                    <a href="product.php?id=<?php echo $row['id']; ?>" class="select-opt">View Details</a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</section>

<footer class="footer-main" style="background: #222; color: #fff; padding: 60px 0 20px 0; margin-top: 50px;">
    <div class="container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 40px; max-width: 1200px; margin: 0 auto; padding: 0 20px;">
        <div class="footer-col">
            <h3 style="color: #1ab394; margin-bottom: 20px;">Infinity<span>Cart.</span></h3>
            <p style="color: #bbb; font-size: 14px;">Your one-stop shop for infinite choices in fashion, electronics, and more. Quality guaranteed.</p>
        </div>
        <div class="footer-col">
            <h4 style="margin-bottom: 20px;">Quick Links</h4>
            <ul style="list-style: none; padding: 0; line-height: 2;">
                <li><a href="shop.php" style="color: #bbb; text-decoration: none;">Shop Now</a></li>
                <li><a href="about.php" style="color: #bbb; text-decoration: none;">About Us</a></li>
                <li><a href="faq.php" style="color: #bbb; text-decoration: none;">FAQ</a></li>
                <li><a href="terms.php" style="color: #bbb; text-decoration: none;">Terms & Conditions</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4 style="margin-bottom: 20px;">Contact Info</h4>
            <p style="color: #bbb; font-size: 14px;"><i class="fa fa-location-dot"></i> 123 Street, Hyderabad, India</p>
            <p style="color: #bbb; font-size: 14px;"><i class="fa fa-envelope"></i> support@infinitycart.com</p>
            <p style="color: #bbb; font-size: 14px;"><i class="fa fa-phone"></i> +91 9876543210</p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
  const swiper = new Swiper('.hero-slider', {
    loop: true,
    autoplay: { delay: 4000, disableOnInteraction: false },
    pagination: { el: '.swiper-pagination', clickable: true },
    navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
  });
</script>
    <div style="text-align: center; margin-top: 40px; border-top: 1px solid #333; padding-top: 20px; font-size: 13px; color: #777;">
        &copy; 2026 Infinity Cart. All Rights Reserved.
    </div>
</footer>

<div class="chat-btn" onclick="toggleChat()">
    <i class="fa fa-comments"></i>
</div>

<div class="chat-window" id="chatWindow">
    <div class="chat-header">
        <span>Infinity Support</span>
        <i class="fa fa-times" onclick="toggleChat()" style="cursor:pointer;"></i>
    </div>
    <div class="chat-body" id="chatBody">
        <div class="bot-msg">Hello! How can I help you today?</div>
    </div>
    <div class="chat-footer">
        <input type="text" id="userInput" placeholder="Type a message...">
        <button onclick="sendMessage()" style="background:none; border:none; color:#1ab394; margin-left:5px; cursor:pointer;"><i class="fa fa-paper-plane"></i></button>
    </div>
</div>

<script>
function toggleChat() {
    var win = document.getElementById('chatWindow');
    win.style.display = (win.style.display === 'flex') ? 'none' : 'flex';
}

function sendMessage() {
    var input = document.getElementById('userInput');
    var body = document.getElementById('chatBody');
    if(input.value.trim() === "") return;

    // User Message
    body.innerHTML += '<div class="user-msg">' + input.value + '</div>';
    
    // Simple Auto-Response Logic
    var msg = input.value.toLowerCase();
    input.value = "";
    
    setTimeout(() => {
        var reply = "I'm not sure about that. Can you please contact our support team?";
        if(msg.includes("order")) reply = "You can track your order in the 'My Orders' section.";
        else if(msg.includes("return")) reply = "We have a 7-day return policy.";
        else if(msg.includes("hello") || msg.includes("hi")) reply = "Hi there! How can I assist you?";

        body.innerHTML += '<div class="bot-msg">' + reply + '</div>';
        body.scrollTop = body.scrollHeight;
    }, 1000);
}
</script>
        </body>
</html>